package com.example.statistics;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


public class Home extends Fragment {
    private int turn = 0;
    List<PieEntry> pieEntryList = new ArrayList<>();
    final int []colors = {Color.parseColor("#0000ff"), Color.parseColor("#ffa500"),
            Color.parseColor("#00bfff"), Color.parseColor("#FFBB86FC"),
            Color.parseColor("#d02090"), Color.parseColor("#b03060")
    };

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle saveInstanceState) {
        View v = inflater.inflate(R.layout.home_layout, container, false);
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://10.0.2.2:9091")
                // when sending data in json format we have to add Gson converter factory
                .addConverterFactory(GsonConverterFactory.create())
                // and build our retrofit builder.
                .build();
        // create an instance for our retrofit api class.
        RetrofitAPI retrofitAPI = retrofit.create(RetrofitAPI.class);
        Button week_button = v.findViewById(R.id.Week_button);
        Button month_button = v.findViewById(R.id.Month_button);
        Button year_button = v.findViewById(R.id.Year_button);
        ProgressBar course_progress = v.findViewById(R.id.course_progress);
        TextView number_of_courses = v.findViewById(R.id.text_number_of_courses);
        TextView percent_of_courses = v.findViewById(R.id.text_percent_courses);
        TextView courses_per_number = v.findViewById(R.id.courses_per_hour);
        ProgressBar parent_progress = v.findViewById(R.id.parent_progress);
        TextView number_of_parents = v.findViewById(R.id.text_number_of_parents);
        TextView percent_of_parents = v.findViewById(R.id.text_percent_parents);
        ProgressBar children_progress = v.findViewById(R.id.children_progress);
        TextView number_of_children = v.findViewById(R.id.text_number_of_children);
        TextView percent_of_children = v.findViewById(R.id.text_percent_children);
        PieChart pie_chart = v.findViewById(R.id.pie_chart);
        BarChart barChart = v.findViewById(R.id.BarChart);
        pie_chart.setDrawHoleEnabled(false);
        pie_chart.setDrawEntryLabels(false);
        pie_chart.getDescription().setEnabled(false);
        pie_chart.getLegend().setEnabled(false);
        PieDataSet pieDataSet = new PieDataSet(pieEntryList,"");
        pieDataSet.setColors(colors);
        PieData pieData = new PieData(pieDataSet);
        int colorWhite = Color.parseColor("#FFFFFFFF");
        pieData.setValueTextColor(colorWhite);
        pieData.setValueTextSize(10f);
        pie_chart.setData(pieData);
        barChart.getDescription().setEnabled(false);
        XAxis xAxis = barChart.getXAxis();
        xAxis.setCenterAxisLabels(true);                  //set text in center
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);     //bottom of chart
        xAxis.setGranularity(1);                            //
        xAxis.setGranularityEnabled(true);
        barChart.setDragEnabled(true);
        barChart.setVisibleXRangeMaximum(3);                //insure
        barChart.getXAxis().setAxisMinimum(0);
        barChart.animate();
        barChart.invalidate();
        barChart.setDragEnabled(true);
        barChart.getLegend().setEnabled(false);

        if (turn == 0) {
            pickedButton(week_button);
            unpickedButton(month_button);
            unpickedButton(year_button);
        }
        if (turn == 1) {
            pickedButton(month_button);
            unpickedButton(week_button);
            unpickedButton(year_button);
        }
        if (turn == 2) {
            pickedButton(year_button);
            unpickedButton(week_button);
            unpickedButton(month_button);
        }
        setProgressBarActivities (course_progress, number_of_courses, percent_of_courses, courses_per_number, retrofitAPI);
        setProgressBarParents (parent_progress, number_of_parents, percent_of_parents, retrofitAPI);
        setProgressBarKids (children_progress, number_of_children, percent_of_children, retrofitAPI );
        setPieChart (pie_chart, pieData, retrofitAPI);
        setBarChart(barChart, retrofitAPI);
        week_button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (turn != 0) {
                    pickedButton(week_button);
                    if (turn == 1)
                        unpickedButton(month_button);
                    else
                        unpickedButton(year_button);
                    turn = 0;
                    setProgressBarActivities (course_progress, number_of_courses, percent_of_courses, courses_per_number, retrofitAPI);
                    setProgressBarParents (parent_progress, number_of_parents, percent_of_parents, retrofitAPI);
                    setProgressBarKids (children_progress, number_of_children, percent_of_children, retrofitAPI );
                    setPieChart (pie_chart, pieData, retrofitAPI);
                    setBarChart(barChart, retrofitAPI);

                }
            }
        });
        month_button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (turn != 1) {
                    pickedButton(month_button);
                    if (turn == 0)
                        unpickedButton(week_button);
                    else
                        unpickedButton(year_button);
                    turn = 1;
                    setProgressBarActivities (course_progress, number_of_courses, percent_of_courses, courses_per_number, retrofitAPI);
                    setProgressBarParents (parent_progress, number_of_parents, percent_of_parents, retrofitAPI);
                    setProgressBarKids (children_progress, number_of_children, percent_of_children, retrofitAPI );
                    setPieChart (pie_chart, pieData, retrofitAPI);
                    setBarChart(barChart, retrofitAPI);

                }
            }
        });
        year_button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (turn != 2) {
                    pickedButton(year_button);
                    if (turn == 1)
                        unpickedButton(month_button);
                    else
                        unpickedButton(week_button);
                    turn = 2;
                    setProgressBarActivities (course_progress, number_of_courses, percent_of_courses, courses_per_number,  retrofitAPI);
                    setProgressBarParents (parent_progress, number_of_parents, percent_of_parents, retrofitAPI);
                    setProgressBarKids (children_progress, number_of_children, percent_of_children,retrofitAPI );
                    setPieChart (pie_chart, pieData, retrofitAPI);
                    setBarChart(barChart, retrofitAPI);
                }
            }
        });
        return v;
    }

    private void pickedButton (Button button){
        button.setTextColor(Color.parseColor("#FFFFFFFF"));
        button.setBackgroundColor(Color.parseColor("#4e7fe7"));
    }
    private void unpickedButton (Button button){
        button.setTextColor(Color.parseColor("#FF000000"));
        button.setBackgroundColor(Color.parseColor("#DCDCDC"));
    }
    private void setProgressBarActivities (ProgressBar progressB, TextView Number, TextView percent, TextView text, RetrofitAPI retrofitAPI){
                    Call<Integer> call = retrofitAPI.getActiveActivities(turn);
                    call.enqueue(new Callback<Integer>() {
                        @Override
                        public void onResponse(Call<Integer> call, Response<Integer> response) {
                            Number.setText(response.body().toString());

                        }

                        @Override
                        public void onFailure(Call<Integer>call, Throwable t) {
                            Number.setText("failed");
                        }
                    });
                    Call <Double> call1 = retrofitAPI.getPercentActivities(turn);
                    call1.enqueue(new Callback<Double>() {
                        @Override
                        public void onResponse(Call<Double> call1, Response<Double> response) {
                            double value = response.body();
                            int val = (int) value;
                            progressB.setProgress(val);
                            if (response.body() < 1)
                                percent.setText(response.body() + "%");
                            else
                            percent.setText(response.body().intValue() + "%");
                            if (response.body().intValue() == 100 || response.body() < 1)
                                percent.setTextSize(10f);
                            else
                            percent.setTextSize(12f);

                        }

                        @Override
                        public void onFailure(Call<Double>call, Throwable t) {
                            percent.setText("-1");
                        }
                    });
                    if (turn == 0)
                    text.setText("Weekly Activities per Hour");
                    else if (turn == 1)
                        text.setText("Monthly Activities per Hour");
                    else
                        text.setText("Yearly Activities per Hour");

    }
    private void setProgressBarParents (ProgressBar progressB, TextView Number, TextView percent, RetrofitAPI retrofitAPI) {
              Call<Integer> call = retrofitAPI.getNewParentsByPeriod(turn);
              call.enqueue(new Callback<Integer>() {
                  @Override
                  public void onResponse(Call<Integer> call, Response<Integer> response) {
                      Number.setText(response.body().toString());

                  }

                  @Override
                  public void onFailure(Call<Integer> call, Throwable t) {
                      Number.setText("failed");
                  }
              });
              Call <Double> call1 = retrofitAPI.newParentsPercentage(turn);
              call1.enqueue(new Callback<Double>() {
                  @Override
                  public void onResponse(Call<Double> call, Response<Double> response) {
                      double value = response.body();
                      int val = (int) value;
                      progressB.setProgress(val);

                      if (response.body() < 1)
                          percent.setText(response.body() + "%");
                      else
                      percent.setText(response.body().intValue() + "%");
                      if (response.body().intValue() == 100 || response.body() < 1)
                          percent.setTextSize(10f);
                      else
                      percent.setTextSize(12f);
                  }

                  @Override
                  public void onFailure(Call<Double> call, Throwable t) {
                      percent.setText("-1");
                  }
              });
    }
    private void setProgressBarKids (ProgressBar progressB, TextView Number, TextView percent, RetrofitAPI retrofitAPI) {
        Call<Integer> call = retrofitAPI.getNewKidsByPeriod(turn);
        call.enqueue(new Callback<Integer>() {
            @Override
            public void onResponse(Call<Integer> call, Response<Integer> response) {
                Number.setText(response.body().toString());

            }

            @Override
            public void onFailure(Call<Integer> call, Throwable t) {
                Number.setText("failed");
            }
        });
        Call <Double> call1 = retrofitAPI.newKidsPercentage(turn);
        call1.enqueue(new Callback<Double>() {
            @Override
            public void onResponse(Call<Double> call, Response<Double> response) {
                double value = response.body();
                int val = (int) value;
                progressB.setProgress(val);
                if (response.body() < 1)
                    percent.setText(response.body() + "%");
                else
                 percent.setText(response.body().intValue() + "%");
                if (response.body().intValue() == 100 || response.body() < 1)
                    percent.setTextSize(10f);
                else
                   percent.setTextSize(12f);
            }

            @Override
            public void onFailure(Call<Double> call, Throwable t) {
                percent.setText("-1");
            }
        });
    }
    private void setPieChart (PieChart pie_chart, PieData pieData, RetrofitAPI retrofitAPI){
        if (turn == 0) {
            pieEntryList.clear();
            Call<Integer []> call = retrofitAPI.kidsPerCategories(turn);
            call.enqueue(new Callback<Integer []>() {
                @Override
                public void onResponse(Call<Integer [] > call , Response<Integer []> response) {
                    Integer [] temp = response.body();
                    for (int i = 0; i < temp.length; i++){
                        pieEntryList.add(new PieEntry (temp[i], ""));
                    }
                    pie_chart.invalidate();
                    pie_chart.setData(pieData);

                }

                @Override
                public void onFailure(Call<Integer []> call, Throwable t) {

                }
            });

        }
        if (turn == 1){
            pieEntryList.clear();
            Call<Integer []> call = retrofitAPI.kidsPerCategories(turn);
            call.enqueue(new Callback<Integer []>() {
                @Override
                public void onResponse(Call<Integer [] > call , Response<Integer []> response) {
                    Integer [] temp = response.body();
                    for (int i = 0; i < temp.length; i++){
                        pieEntryList.add(new PieEntry (temp[i], ""));
                    }
                    pie_chart.invalidate();
                    pie_chart.setData(pieData);

                }

                @Override
                public void onFailure(Call<Integer []> call, Throwable t) {

                }
            });
        }
        if (turn == 2){
            pieEntryList.clear();
            Call<Integer []> call = retrofitAPI.kidsPerCategories(turn);
            call.enqueue(new Callback<Integer []>() {
                @Override
                public void onResponse(Call<Integer [] > call , Response<Integer []> response) {
                    Integer [] temp = response.body();
                    for (int i = 0; i < temp.length; i++){
                        pieEntryList.add(new PieEntry (temp[i], ""));
                    }
                    pie_chart.invalidate();
                    pie_chart.setData(pieData);

                }

                @Override
                public void onFailure(Call<Integer []> call, Throwable t) {

                }
            });
        }

    }
        private void setBarChart (BarChart barChart, RetrofitAPI retrofitAPI){

            if (turn == 0) {
                barChart.clear();
                String[] days = new String[]{"Sunday", "Monday", "Tuesday","Wednesday", "Thursday", "Friday", "Saturday"};
                Call<List <Integer []>> call = retrofitAPI.totalPerCatgoryGraph(turn);
                call.enqueue(new Callback<List <Integer []>>() {
                    @Override
                    public void onResponse(Call<List <Integer []>> call , Response<List <Integer []>> response) {
                        List <Integer[]> info = response.body();
                        BarDataSet [] category_set = new BarDataSet[info.size()];
                        List <List <BarEntry>> allSets = new ArrayList<>();
                        BarData data = new BarData();
                        for (int i = 0; i < info.size(); i++){
                            allSets.add(new ArrayList<>());
                            Integer [] numPerDay = info.get(i);
                            for (int j = 0; j < 7; j++){
                                allSets.get(i).add(new BarEntry (j, numPerDay[j]));
                            }
                            category_set[i] = new BarDataSet(allSets.get(i), " ");
                            category_set[i].setColors(colors[i]);
                            data.addDataSet(category_set[i]);
                        }
                        data.setBarWidth(0.15f);
                        barChart.invalidate();
                        barChart.setData(data);
                        float barSpace = 0.03f;
                        float groupSpace = 0.5f;
                        barChart.groupBars(0, groupSpace, barSpace);
                        XAxis xAxis = barChart.getXAxis();
                        xAxis.setValueFormatter(new IndexAxisValueFormatter(days)); //set the x
                    }

                    @Override
                    public void onFailure(Call<List <Integer []>>call, Throwable t) {

                    }
                });

            }
            if (turn ==1) {
                barChart.clear();
                String[] days = new String[]{"1 week", "2 week", "3 week", "4 week", "5 week"};
                Call<List <Integer []>> call = retrofitAPI.totalPerCatgoryGraph(turn);
                call.enqueue(new Callback<List <Integer []>>() {
                    @Override
                    public void onResponse(Call<List <Integer []>> call , Response<List <Integer []>> response) {
                        List <Integer[]> info = response.body();
                        BarDataSet [] category_set = new BarDataSet[info.size()]; //number of categories
                        List <List <BarEntry>> allSets = new ArrayList<>();
                        BarData data = new BarData();
                        for (int i = 0; i < info.size(); i++){
                            allSets.add(new ArrayList<>());
                            Integer [] numPerDay = info.get(i);
                            for (int j = 0; j < 5; j++){
                                allSets.get(i).add(new BarEntry (j, numPerDay[j]));
                            }
                            category_set[i] = new BarDataSet(allSets.get(i), " ");
                            category_set[i].setColors(colors[i]);
                            data.addDataSet(category_set[i]);
                        }
                        data.setBarWidth(0.15f);
                        barChart.invalidate();
                        barChart.setData(data);
                        float barSpace = 0.03f;
                        float groupSpace = 0.5f;
                        barChart.groupBars(0, groupSpace, barSpace);
                        XAxis xAxis = barChart.getXAxis();
                        xAxis.setValueFormatter(new IndexAxisValueFormatter(days)); //set the x
                    }

                    @Override
                    public void onFailure(Call<List <Integer []>>call, Throwable t) {

                    }
                });
            }
            if (turn ==2) {
                barChart.invalidate();
                barChart.clear();
                String[] days = new String[]{"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"};
                Call<List <Integer []>> call = retrofitAPI.totalPerCatgoryGraph(turn);
                call.enqueue(new Callback<List <Integer []>>() {
                    @Override
                    public void onResponse(Call<List <Integer []>> call , Response<List <Integer []>> response) {
                        List <Integer[]> info = response.body();
                        BarDataSet [] category_set = new BarDataSet[info.size()];
                        List <List <BarEntry>> allSets = new ArrayList<>();
                        BarData data = new BarData();
                        for (int i = 0; i < info.size(); i++){
                            allSets.add(new ArrayList<>());
                            Integer [] numPerDay = info.get(i);
                            for (int j = 0; j < 12; j++){
                                allSets.get(i).add(new BarEntry (j, numPerDay[j]));
                            }
                            category_set[i] = new BarDataSet(allSets.get(i), " ");
                            category_set[i].setColors(colors[i]);
                            data.addDataSet(category_set[i]);
                        }
                        data.setBarWidth(0.15f);
                        barChart.invalidate();
                        barChart.setData(data);
                        float barSpace = 0.03f;
                        float groupSpace = 0.5f;
                        barChart.groupBars(0, groupSpace, barSpace);
                        XAxis xAxis = barChart.getXAxis();
                        xAxis.setValueFormatter(new IndexAxisValueFormatter(days)); //set the x
                    }

                    @Override
                    public void onFailure(Call<List <Integer []>>call, Throwable t) {

                    }
                });
            }
    }

}
