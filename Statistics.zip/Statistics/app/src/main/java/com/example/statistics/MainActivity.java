package com.example.statistics;

import android.os.Bundle;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {
    private Home home = new Home();
    private Courses course = new Courses();
    private Leaders leader = new Leaders();
    private More more = new More();
    private Users user = new Users();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BottomNavigationView bottomNav = findViewById(R.id.Bottom_navigation);
        bottomNav.setOnNavigationItemSelectedListener(navListener);
        getSupportFragmentManager().beginTransaction().replace(R.id.Primary_layout,home).commit();
    }
      private BottomNavigationView.OnNavigationItemSelectedListener navListener = new BottomNavigationView.OnNavigationItemSelectedListener(){

          @Override
          public boolean onNavigationItemSelected(@NonNull MenuItem item) {
              Fragment selectedFragment = null;
              switch (item.getItemId()){
                  case R.id.home :
                      selectedFragment = home;
                      break;
                  case R.id.courses:
                      selectedFragment = course;
                      break;
                  case R.id.leaders:
                      selectedFragment = leader;
                      break;
                  case R.id.more:
                      selectedFragment = more;
                      break;
                  case R.id.users:
                      selectedFragment = user;
                      break;

              }
                getSupportFragmentManager().beginTransaction().replace(R.id.Primary_layout,selectedFragment ).commit();
              return true;
          }
      };


}