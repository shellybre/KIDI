package com.example.statistics;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;

public interface RetrofitAPI {


    @GET ("/getActiveActivities/{period}")
    Call <Integer> getActiveActivities (@Path("period") int period);

    @GET ("getPercentActivities/{period}")
    Call <Double> getPercentActivities (@Path("period") int period);

    @GET ("/getNewParentsByPeriod/{period}")
    Call<Integer>  getNewParentsByPeriod(@Path("period") int period);

    @GET ("/newParentsPercentage/{period}")
    Call <Double> newParentsPercentage  (@Path("period") int period);

    @GET ("/getNewKidsByPeriod/{period}")
    Call <Integer> getNewKidsByPeriod (@Path("period") int period);

    @GET ("/newKidsPercentage/{period}")
    Call <Double> newKidsPercentage  (@Path("period") int period);

    @GET ("/kidsPerCategories/{period}")
    Call <Integer[]> kidsPerCategories (@Path("period") int period);


    @GET ("/totalPerCatgoryGraph/{period}")
    Call <List<Integer[]>> totalPerCatgoryGraph  (@Path("period") int period);


}
