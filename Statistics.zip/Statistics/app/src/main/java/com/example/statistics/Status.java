package com.example.statistics;

public enum Status {
    Active,
    InActive,
    Pending
}
